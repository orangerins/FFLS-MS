<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $query = "UPDATE laundry_request SET status = ? WHERE laundry_request_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $order_id);

    if ($stmt->execute()) {

        echo "<script>
                alert('Order updated successfully');
                window.location.href = 'admin-orders.php';
              </script>";
        exit();
    } else {
        echo "Error updating order.";
    }
}
?>
