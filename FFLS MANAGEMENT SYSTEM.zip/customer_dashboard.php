<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['client_logged_in'], $_SESSION['client_username'])) {
    echo "<script>alert('Please log in to view your dashboard.'); window.location.href='customer_login.php';</script>";
    exit();
}

$clientUsername = mysqli_real_escape_string($conn, $_SESSION['client_username']);
$sqlUser = "SELECT customer_id, first_name, last_name, email, username, contact_number, street, barangay, city 
            FROM customer 
            WHERE username='$clientUsername'";
$resultUser = $conn->query($sqlUser);

if ($resultUser && $resultUser->num_rows > 0) {
    $user = $resultUser->fetch_assoc();
    $customerId = $user['customer_id'];
} else {
    echo "<script>alert('User not found.'); window.location.href='customer_login.php';</script>";
    exit();
}


$sqlOrders = "SELECT laundry_request_id, date_placed, status 
              FROM laundry_request 
              WHERE customer_id='$customerId' 
              ORDER BY date_placed DESC 
              LIMIT 5";
$resultOrders = $conn->query($sqlOrders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFold Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-dropdown {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            position: relative;
        }

        .user-dropdown span {
            margin-left: 10px;
            font-weight: bold;
        }

        .user-dropdown img {
            width: 20px;
            height: 20px;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-top: 70px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.shift {
            margin-left: 260px;
        }

        .user-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .user-info h2 {
            margin-bottom: 15px;
            color: #333;
        }

        .user-info p {
            margin: 5px 0;
            color: #555;
        }

        .edit-btn {
            background-color: #82b8ef;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .recent-orders {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .recent-orders h3 {
            margin-bottom: 15px;
            color: #333;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 8px;
            border: 1px solid #eee;
            border-radius: 5px;
        }

        .order-item span {
            color: #555;
        }

        .edit-form {
            display: none;
            flex-direction: column;
            gap: 10px;
        }

        .edit-form input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .save-btn {
            background-color: #82b8ef;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<header>
    <div class="logo-menu">
        <img src="FFLSlogo.png" alt="Logo" style="height:50px;">
        <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
    </div>
    <div class="user-dropdown" id="userDropdown">
        <span><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></span>
        <img src="ad-icon.png" alt="Dropdown Icon">
        <div class="logout-box" id="logoutBox">
            <a href="customer_logout.php">Logout</a>
        </div>
    </div>
</header>

<div class="sidebar" id="sidebar">
    <ul>
        <li><img src="d-icon.png" alt="Dashboard"><a href="customer_dashboard.php">Dashboard</a></li>
        <li><img src="O-icon.png" alt="Orders"><a href="customer_orders.php">Orders</a></li>
        <li><img src="p-icon.png" alt="Payments"><a href="customer_payment.php">Payments</a></li>
    </ul>
</div>

<div class="content" id="mainContent">
    <div class="user-info">
        <h2>User Information</h2>
        <p><strong>Name:</strong> <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
        <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
        <p><strong>Contact Number:</strong> <?= htmlspecialchars($user['contact_number']) ?></p>
        <p><strong>Address:</strong> <?= htmlspecialchars($user['street'] . ', ' . $user['barangay'] . ', ' . $user['city']) ?></p>

        <button class="edit-btn" id="editBtn">Edit Information</button>
        <form class="edit-form" id="editForm" action="customer_update_profile.php" method="POST">
            <input type="text" name="first_name" placeholder="First Name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
            <input type="text" name="last_name" placeholder="Last Name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
            <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($user['email']) ?>" required>
            <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($user['username']) ?>" required>
            <input type="text" name="contact_number" placeholder="Contact Number" value="<?= htmlspecialchars($user['contact_number']) ?>" required>
            <input type="text" name="street" placeholder="Street" value="<?= htmlspecialchars($user['street']) ?>" required>
            <input type="text" name="barangay" placeholder="Barangay" value="<?= htmlspecialchars($user['barangay']) ?>" required>
            <input type="text" name="city" placeholder="City" value="<?= htmlspecialchars($user['city']) ?>" required>
            <button type="submit" class="save-btn">Save Changes</button>
        </form>
    </div>

    <div class="recent-orders">
        <h3>Recent Orders</h3>
        <?php if ($resultOrders && $resultOrders->num_rows > 0): ?>
            <?php while ($order = $resultOrders->fetch_assoc()): ?>
                <div class="order-item">
                    <span>Order #<?= htmlspecialchars($order['laundry_request_id']) ?> - <?= date("F j, Y", strtotime($order['date_placed'])) ?></span>
                    <span>Status: <?= htmlspecialchars($order['status']) ?></span>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No recent orders found.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    const menuBtn = document.getElementById('menu-btn');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const userDropdown = document.getElementById('userDropdown');
    const logoutBox = document.getElementById('logoutBox');
    const editBtn = document.getElementById('editBtn');
    const editForm = document.getElementById('editForm');

    menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        mainContent.classList.toggle('shift');
    });

    userDropdown.addEventListener('click', () => {
        logoutBox.style.display = logoutBox.style.display === 'block' ? 'none' : 'block';
    });

    document.addEventListener('click', (e) => {
        if (!userDropdown.contains(e.target)) {
            logoutBox.style.display = 'none';
        }
    });

    editBtn.addEventListener('click', () => {
        editForm.style.display = 'flex';
        editBtn.style.display = 'none';
    });
</script>
</body>
</html>