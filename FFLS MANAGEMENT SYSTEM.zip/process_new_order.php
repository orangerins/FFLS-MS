<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $washType = $_POST['wash_type'];
    $weight = floatval($_POST['weight']);
    $status = $_POST['status'];
    $datePlaced = $_POST['date_placed'];
    $addonsSelected = isset($_POST['addons']) ? $_POST['addons'] : [];

    $totalPayment = 0;
    $customerId = null;


    $nameParts = explode(' ', trim($customerName));
    $firstName = mysqli_real_escape_string($conn, $nameParts[0] ?? '');
    $lastName = mysqli_real_escape_string($conn, end($nameParts) ?: '');

   
    $checkCustomerStmt = $conn->prepare("SELECT customer_id FROM customer WHERE first_name = ? AND last_name = ?");
    $checkCustomerStmt->bind_param("ss", $firstName, $lastName);
    $checkCustomerStmt->execute();
    $checkCustomerResult = $checkCustomerStmt->get_result();

    if ($checkCustomerResult->num_rows > 0) {
        $customerId = $checkCustomerResult->fetch_assoc()['customer_id'];
    } else {
        $insertCustomerStmt = $conn->prepare("INSERT INTO customer (first_name, last_name) VALUES (?, ?)");
        $insertCustomerStmt->bind_param("ss", $firstName, $lastName);
        if ($insertCustomerStmt->execute()) {
            $customerId = $conn->insert_id;
        } else {
            echo "<script>alert('Error creating customer: " . $insertCustomerStmt->error . "'); window.history.back();</script>";
            exit();
        }
        $insertCustomerStmt->close();
    }
    $checkCustomerStmt->close();


    if ($washType === 'Wash Only') {
        $totalPayment = ceil($weight / 8) * 50;
    } elseif ($washType === 'Full Service') {
        $totalPayment = ceil($weight / 8) * 180;
    }


    if (!empty($addonsSelected)) {
        $addonIds = implode(',', array_map('intval', $addonsSelected));
        $addonPriceResult = $conn->query("SELECT price FROM inventory WHERE item_id IN ($addonIds)");
        while ($row = $addonPriceResult->fetch_assoc()) {
            $totalPayment += $row['price'];
        }
    }

    $dateParts = explode('/', $datePlaced);
    $mysqlDate = (count($dateParts) === 3 && checkdate($dateParts[0], $dateParts[1], $dateParts[2]))
        ? "{$dateParts[2]}-{$dateParts[0]}-{$dateParts[1]}"
        : date('Y-m-d');

    $insertOrderStmt = $conn->prepare("INSERT INTO laundry_request (customer_id, date_placed, status, total_price, weight, wash_type) 
                                       VALUES (?, ?, ?, ?, ?, ?)");
    $insertOrderStmt->bind_param("isssds", $customerId, $mysqlDate, $status, $totalPayment, $weight, $washType);
    
    if ($insertOrderStmt->execute()) {
        $orderId = $conn->insert_id;

        $packagingDeductQty = ceil($weight / 8);  
        $chemicalMultiplier = floor($weight / 8);      


        $updateInventorySql = "
            UPDATE inventory 
            SET quantity = CASE 
                WHEN item_name LIKE '%Liquid Detergent%' THEN quantity - (2 * ?)
                WHEN item_name LIKE '%Fabric Conditioner%' THEN quantity - (2 * ?)
                WHEN category = 'Packaging' THEN quantity - ?
                ELSE quantity
            END
            WHERE item_name LIKE '%Liquid Detergent%' 
               OR item_name LIKE '%Fabric Conditioner%' 
               OR category = 'Packaging'
        ";
        $updateInventoryStmt = $conn->prepare($updateInventorySql);
        $updateInventoryStmt->bind_param("iii", $chemicalMultiplier, $chemicalMultiplier, $packagingDeductQty);

        if (!$updateInventoryStmt->execute()) {
            echo "<script>alert('Order added, but inventory update failed: " . $updateInventoryStmt->error . "'); window.location.href='admin-orders.php';</script>";
            exit();
        }

        echo "<script>alert('Order added successfully!'); window.location.href='admin-orders.php';</script>";
    } else {
        echo "<script>alert('Error adding order: " . $insertOrderStmt->error . "'); window.history.back();</script>";
    }

    $insertOrderStmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
