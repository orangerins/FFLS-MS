<?php
include 'db_connection.php'; 


$laundry_request_id = $_GET['laundry_request_id'] ?? null;

if ($laundry_request_id) {
 
    $query = "
        SELECT lr.laundry_request_id, lr.date_placed, lr.status, lr.wash_type, lr.total_price,
               CONCAT(c.first_name, ' ', c.last_name) AS customer_name
        FROM laundry_request lr
        LEFT JOIN customer c ON lr.customer_id = c.customer_id
        WHERE lr.laundry_request_id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $laundry_request_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    if ($order) {
        echo "<p><strong>Order ID:</strong> " . htmlspecialchars($order['laundry_request_id']) . "</p>";
        echo "<p><strong>Customer Name:</strong> " . htmlspecialchars($order['customer_name']) . "</p>";
        echo "<p><strong>Date Placed:</strong> " . htmlspecialchars($order['date_placed']) . "</p>";
        echo "<p><strong>Status:</strong> " . htmlspecialchars($order['status']) . "</p>";
        echo "<p><strong>Wash Type:</strong> " . htmlspecialchars($order['wash_type']) . "</p>";
        echo "<p><strong>Price:</strong> ₱" . htmlspecialchars($order['total_price']) . "</p>";
    } else {
        echo "No order found.";
    }
} else {
    echo "Invalid order ID.";
}
?>
