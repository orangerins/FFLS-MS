<?php
session_start();
include 'db_connection.php';

$customer_id = $_SESSION['client_id'] ?? null;

if (!$customer_id) {
    header("Location: customer_login.php");
    exit();
}

$sql = "SELECT
          p.payment_id,
          p.laundry_request_id,
          p.payment_date,
          p.amount_paid,
          p.payment_method,
          lr.status AS order_status,
          lr.date_placed
        FROM payment p
        JOIN laundry_request lr ON p.laundry_request_id = lr.laundry_request_id
        WHERE lr.customer_id = ?
        ORDER BY p.payment_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFold Payments</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .sidebar ul li.active {
            background-color: #75b2f0;
        }

        .sidebar ul li.active span {
            color: rgb(255, 255, 255);
            font-size: 16px;
        }

        .content {
            margin-top: 70px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.shift {
            margin-left: 260px;
        }

        .search-container {
            display: flex;
            justify-content: flex-start; 
            align-items: center;         
            gap: 10px;
            margin-top: 20px;            
        }

        .search-container input {
            padding: 8px;
            border: 1px solid #aed1fc;
            border-radius: 5px;
            width: 250px;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        .payment-table th,
        .payment-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        .payment-table th {
            background-color: #165a91;
            color: white;
        }

        .status {
            font-weight: bold;
        }

        .status.paid {
            color: green;
        }

        .status.partially {
            color: goldenrod;
        }

        .user-dropdown {
            position: relative;
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

    </style>
</head>
<body>

   <header>
    <div class="logo-menu">
        <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;">
        <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
    </div>
</header>

<div class="sidebar" id="sidebar">
    <ul>
        <li><img src="d-icon.png" alt="Dashboard"><a href="customer_dashboard.php">Dashboard</a></li>
        <li><img src="O-icon.png" alt="Orders"><a href="customer_orders.php">Orders</a></li>
        <li class="active"><img src="p-icon.png" alt="Payments"><a href="customer_payment.php">Payments</a></li>
    </ul>
</div>

<div class="content" id="main-content">
    <h2>Payments History</h2>

    <div class="search-container">
        <input type="text" placeholder="Search Date or Status" id="searchInput" autocomplete="off">
    </div>

    <table class="payment-table" id="paymentTable">
        <thead>
            <tr>
                <th>Payment ID</th>
                <th>Order #</th>
                <th>Date Paid</th>
                <th>Amount Paid</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows === 0): ?>
                <tr><td colspan="5">No payment history found.</td></tr>
            <?php else: ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['payment_id']) ?></td>
                    <td><?= htmlspecialchars($row['laundry_request_id']) ?></td>
                    <td><?= date('M d, Y', strtotime($row['payment_date'])) ?></td>
                    <td>₱<?= number_format($row['amount_paid'], 2) ?></td>
                    <td>
                        <span class="status paid">Paid</span>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>

    const menuBtn = document.getElementById('menu-btn');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');

    menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        mainContent.classList.toggle('shift');
    });


    function toggleLogout() {
        const logoutBox = document.getElementById('logoutBox');
        if (logoutBox.style.display === 'block') {
            logoutBox.style.display = 'none';
        } else {
            logoutBox.style.display = 'block';
        }
    }


    document.addEventListener('click', function(event) {
        const userDropdown = document.getElementById('userDropdown');
        const logoutBox = document.getElementById('logoutBox');
        if (!userDropdown.contains(event.target)) {
            logoutBox.style.display = 'none';
        }
    });


    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('keyup', function() {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll('#paymentTable tbody tr');

        rows.forEach(row => {
            if (row.querySelector('td').colSpan === 5) {

                row.style.display = filter ? 'none' : '';
                return;
            }
            const datePaid = row.cells[2].textContent.toLowerCase();
            const status = row.cells[4].textContent.toLowerCase();
            if (datePaid.includes(filter) || status.includes(filter)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>
