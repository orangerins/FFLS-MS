<?php
include 'db_connection.php';

if (!isset($_GET['laundry_request_id'])) {
    die("Order ID is missing.");
}

$order_id = $_GET['laundry_request_id'];

$query = "SELECT * FROM laundry_request WHERE laundry_request_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

$statuses = ['Pending', 'Washing', 'Drying', 'Folding', 'Ready for Pick-up', 'Completed'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .status-box {
            background-color: #82b8ef;
            padding: 20px;
            margin: 50px auto;
            width: 400px;
            border-radius: 10px;
            text-align: center;
        }
        select {
            padding: 5px;
            border-radius: 5px;
        }
        .button-group {
            margin-top: 20px;
        }
        .button-group button {
            padding: 8px 16px;
            margin: 0 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .update-btn {
            background-color: #4CAF50;
            color: white;
        }
        .cancel-btn {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>

<div class="status-box">
    <h2>Edit Order #<?= $order['laundry_request_id'] ?></h2>
    <form action="update_order.php" method="POST">
        <input type="hidden" name="order_id" value="<?= $order['laundry_request_id'] ?>">

        <p><strong>Main Status:</strong></p>
        <select name="status">
            <?php foreach ($statuses as $status): ?>
                <option value="<?= $status ?>" <?= $order['status'] === $status ? 'selected' : '' ?>><?= $status ?></option>
            <?php endforeach; ?>
        </select>

        <p><strong>Sub-Statuses</strong></p>
        <?php
        $subStatuses = ['Washing', 'Drying', 'Folding', 'Ready for Pick-up'];
        foreach ($subStatuses as $step) {
            if ($order['status'] === $step) {
                $stepStatus = 'In Progress';
            } elseif (array_search($step, $statuses) < array_search($order['status'], $statuses)) {
                $stepStatus = 'Completed';
            } else {
                $stepStatus = 'Pending';
            }

            echo "<label for='{$step}'><strong>{$step}:</strong></label>";
            echo "<select name='{$step}' id='{$step}'>";
            echo "<option value='Pending'" . ($stepStatus == 'Pending' ? ' selected' : '') . ">Pending</option>";
            echo "<option value='In Progress'" . ($stepStatus == 'In Progress' ? ' selected' : '') . ">In Progress</option>";
            echo "<option value='Completed'" . ($stepStatus == 'Completed' ? ' selected' : '') . ">Completed</option>";
            echo "</select><br><br>";
        }
        ?>

        <div class="button-group">
            <button type="submit" class="update-btn">Update</button>
            <a href="admin-orders.php"><button type="button" class="cancel-btn">Cancel</button></a>
        </div>
    </form>
</div>

</body>
</html>
