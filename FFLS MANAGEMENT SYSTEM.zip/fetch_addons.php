<?php
include('db_connection.php');

$result = $conn->query("SELECT * FROM inventory WHERE item_name IN ('Liquid Detergent', 'Fabric Conditioner')");
$addons = [];

while ($row = $result->fetch_assoc()) {
    $addons[] = $row;
}

echo json_encode($addons);
?>
