<?php
session_start();
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

  
    $query = "SELECT * FROM customer WHERE username = '$username' LIMIT 1";
    $result = $conn->query($query);

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

   
        if ($password === $user['password']) {
         
            $_SESSION['client_logged_in'] = true;
            $_SESSION['client_username'] = $user['username'];
            $_SESSION['client_id'] = $user['customer_id'];

            echo "<script>
                    alert('Login successful!');
                    window.location.href = 'customer_dashboard.php';
                  </script>";
            exit();
        } else {
            echo "<script>
                    alert('Incorrect password.');
                    window.location.href = 'customer_login.php';
                  </script>";
            exit();
        }
    } else {
        echo "<script>
                alert('Username not found.');
                window.location.href = 'customer_login.php';
              </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFold Laundry Services - Customer Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }
        .right-side {
            width: 30%;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            text-align: center;
        }
        .logo {
            width: 230px;
            margin-bottom: 20px;
        }
        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 350px;
            text-align: left;
        }
        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .buttons {
            display: flex;
            justify-content: space-between;
        }
        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }
        .login {
            background-color: #6a9ff8;
            color: white;
        }
        .signup {
            background-color: white;
            border: 1px solid #6a9ff8;
            color: #6a9ff8;
        }
        .signup:hover {
            background-color: #6a9ff8;
            color: white;
        }
    </style>
</head>
<body>

    <div class="left-side"></div>

    <div class="right-side">
        <img src="FFLSlogo.png" alt="FreshFold Logo" class="logo">
        <form class="input-container" method="POST" action="">
            <h2>Customer Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter password" required>

            <div class="buttons">
                <button type="button" class="signup" onclick="redirectToSignUp()">Sign Up</button>
                <button type="submit" class="login">Login</button>
            </div>
        </form>
    </div>

    <script>
        function redirectToSignUp() {
            window.location.href = "customer_sign_up.php";
        }
    </script>

</body>
</html>
