<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$adminUsername = $_SESSION['admin_username'];

function getAllOrders($conn) {
    $sql = "SELECT lr.laundry_request_id AS order_id,
                    c.customer_id,
                    c.first_name,
                    c.last_name,
                    lr.date_placed AS order_date,
                    lr.total_price AS total_amount,
                    lr.status,
                    lr.wash_type
            FROM laundry_request lr
            JOIN customer c ON lr.customer_id = c.customer_id
            ORDER BY lr.date_placed DESC";
    $result = $conn->query($sql);
    $orders = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    return $orders;
}

if (isset($_POST['update_status']) && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $orderId = intval($_POST['order_id']);
    $newStatus = mysqli_real_escape_string($conn, $_POST['new_status']);

    $updateSql = "UPDATE laundry_request SET status = ? WHERE laundry_request_id = ?";
    $updateStmt = $conn->prepare($updateSql);
    if ($updateStmt) {
        $updateStmt->bind_param("si", $newStatus, $orderId);
        if ($updateStmt->execute()) {
            echo "success"; 
        } else {
            echo "error: " . $updateStmt->error;
        }
        $updateStmt->close();
    } else {
        echo "error: " . $conn->error;
    }
    exit(); 
}

$orders = getAllOrders($conn);


$addonsSql = "SELECT item_id, item_name, price
              FROM inventory
              WHERE category = 'Cleaning Supplies'
                AND (item_name LIKE '%Liquid Detergent%' OR item_name LIKE '%Fabric Conditioner%')
                AND quantity > 0
              ORDER BY item_name";
$addonsResult = $conn->query($addonsSql);
$addons = [];
if ($addonsResult && $addonsResult->num_rows > 0) {
    while ($row = $addonsResult->fetch_assoc()) {
        $addons[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders - FreshFold Laundry Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
     
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow-x: auto;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
            color: white;
            font-size: 20px;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
            position: relative;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .user-profile span {
            font-size: 14px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
            overflow-y: auto;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-left: 20px;
            margin-top: 80px;
            padding: 20px;
            transition: margin-left 0.3s ease-in-out;
            overflow-y: auto;
            height: calc(100vh - 80px);
        }

        .content.shift {
            margin-left: 260px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 button {
            background-color: #96c7f9; 
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        h1 button:hover {
            background-color: #82b8ef; 
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #96c7f9;
            font-weight: bold;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .action-links {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .action-link {
            color: #82b8ef;
            cursor: pointer;
        }

        .action-link.delete {
            color: #f44336;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .status-select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: white;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

        .modal-dialog {
            margin: 1.75rem auto; 
            max-width: 800px; 
        }

        .modal-content {
            border-radius: 0.3rem;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #dee2e6;
            border-top-left-radius: 0.3rem;
            border-top-right-radius: 0.3rem;
        }

        .modal-title {
            margin-bottom: 0;
            line-height: 1.5;
            font-size: 1.25rem;
            font-weight: 500;
        }

        .btn-close {
            padding: 0.5rem 0.5rem;
            margin: -0.5rem -0.5rem -0.5rem auto;
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            opacity: .5;
            background-color: transparent;
            border: 0;
            border-radius: 0.3rem;
        }

        .btn-close:hover {
            opacity: .75;
        }

        .modal-body {
            padding: 1rem 1.5rem;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            padding: 1rem 1.5rem;
            border-top: 1px solid #dee2e6;
            border-bottom-right-radius: 0.3rem;
            border-bottom-left-radius: 0.3rem;
        }

        .form-label {
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border-radius: 0.25rem;
            transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
            margin-bottom: 1rem;
        }

        .form-select {
            width: 100%;
            padding: 0.375rem 2.25rem 0.375rem 0.75rem;
            -moz-padding-start: calc(0.75rem - 3px);
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 12px;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            margin-bottom: 1rem;
        }

        .form-check {
            margin-bottom: 0.5rem;
        }

        .form-check-input {
            width: 1em;
            height: 1em;
            margin-top: 0.25em;
            vertical-align: top;
            background-color: #fff;
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            border: 1px solid rgba(0,0,0,.25);
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
        }

        .form-check-input[type=checkbox] {
            border-radius: 0.25em;
        }

        .form-check-input:checked {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .form-check-input:focus {
            border-color: #86b7fe;
            outline: 0;
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25);
        }

        .form-check-label {
            margin-left: 0.5em;
        }

        #addOrderModal {
            display: none; 
        }

        .status-text {
            display: inline-block;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #f9f9f9;
            min-width: 120px;
            text-align: center;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            width: 60%;
            border-radius: 10px;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="Logo" style="height: 40px;">
            <button id="menu-btn">
                <img src="m-icon.png" alt="Menu">
            </button>
        </div>
    <div class="user-profile" id="user-profile">
        <span><?php echo htmlspecialchars($adminUsername); ?></span>
        <img src="ad-icon.png" alt="User Icon">
        <div class="logout-box" id="logout-box">
            <a href="admin_login.php">Logout</a>
        </div>
    </div>
    </header>
    <div class="sidebar" id="sidebar">
        <ul>
            <li><a href="admin-dashboard.php"><img src="d-icon.png"></i> Dashboard</a></li>
            <li><a href="admin-orders.php" class="active"><img src="o-icon.png"></i> Orders</a></li>
            <li><a href="admin-customers.php"><img src="c-icon.png"></i> Customers</a></li>
            <li><a href="admin-inventory.php"><img src="i-icon.png"></i> Inventory</a></li>
            <li><a href="admin-payments.php"><img src="p-icon.png"></i> Payments</a></li>
        </ul>
    </div>

    <div class="content" id="mainContent">
        <h1>Orders</h1>
        <div class="search-container" style="margin-bottom: 20px;">
            <input type="text" id="orderSearch" placeholder="Search orders..." class="form-control" style="max-width: 300px;">
        </div>
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
        <?php endif; ?>
<table>
    <thead>
        <tr>
            <th>Order ID</th>
            <th>Customer ID</th>
            <th>Customer Name</th>
            <th>Date Placed</th>
            <th>Wash Type</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($orders)): ?>
            <tr><td colspan='8'>No orders found.</td></tr>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo htmlspecialchars(sprintf('%04d', $order['order_id'])); ?></td>
                    <td><?php echo htmlspecialchars(sprintf('%03d', $order['customer_id'])); ?></td>
                    <td><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($order['wash_type']); ?></td>
                    <td>₱<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></td>
                    <td>
                        <?php
                            $status = htmlspecialchars($order['status']);
                            $statusColor = '';

                            switch (strtolower($status)) {
                                case 'pending':
                                    $statusColor = 'color: #f1c40f; font-weight: bold;'; 
                                    break;
                                case 'washing':
                                    $statusColor = 'color: #f39c12; font-weight: bold;';
                                    break;
                                case 'drying':
                                    $statusColor = 'color: #e67e22; font-weight: bold;'; 
                                    break;
                                case 'folding':
                                    $statusColor = 'color: #f39c12; font-weight: bold;'; 
                                    break;
                                case 'ready for pick up':
                                    $statusColor = 'color: #0077b6; font-weight: bold;'; 
                                    break;
                                case 'completed':
                                    $statusColor = 'color: #27ae60; font-weight: bold;'; 
                                    break;
                                default:
                                    $statusColor = 'color: #333; font-weight: bold;';
                            }
                            echo "<span style='$statusColor'>$status</span>";
                        ?>
                    </td>
                    <td>
                        <div class="action-links">
                            <span class='action-link' onclick='viewOrderDetails(<?= (int)$order["order_id"] ?>)'>View</span>
                            <span class='action-link' onclick='editOrder(<?= (int)$order["order_id"] ?>)'>Edit</span>
                            <span class='action-link delete-btn' data-id='<?= (int)$order["order_id"] ?>' style='color: red;'>Delete</span>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<div class="modal fade" id="order-details-modal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderDetailsModalLabel">Order Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="order-details-content">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    const menuBtn = document.getElementById('menu-btn');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const userProfile = document.getElementById('user-profile');
    const logoutBox = document.getElementById('logout-box');

    menuBtn.onclick = () => {
        sidebar.classList.toggle('active');
        content.classList.toggle('shift');
    };

    userProfile.onclick = (e) => {
        logoutBox.style.display = logoutBox.style.display === 'block' ? 'none' : 'block';
        e.stopPropagation();
    };

    document.addEventListener('click', (e) => {
        if (!userProfile.contains(e.target)) {
            logoutBox.style.display = 'none';
        }
    });
    document.getElementById('orderSearch').addEventListener('keyup', function() {
        const query = this.value.toLowerCase();
        const rows = document.querySelectorAll('table tbody tr');
        rows.forEach(row => {
            const rowText = row.textContent.toLowerCase();
            row.style.display = rowText.includes(query) ? '' : 'none';
        });
    });


    function viewOrderDetails(laundryRequestId) {
        $.ajax({
            url: 'view_order.php?laundry_request_id=' + laundryRequestId,
            method: 'GET',
            dataType: 'html',
            success: function (response) {
                document.getElementById('order-details-content').innerHTML = response;
                const modal = new bootstrap.Modal(document.getElementById('order-details-modal'));
                modal.show();
            },
            error: function (xhr, status, error) {
                alert('AJAX Error: ' + error + "\n" + xhr.responseText);
            }
        });
    }

function editOrder(id) {
    window.location.href = "edit_order.php?laundry_request_id=" + id;
}

   document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const laundryRequestId = this.getAttribute('data-id'); 
            const row = this.closest('tr');

            if (confirm("Are you sure you want to delete this order?")) {
                fetch('delete_order.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'laundry_request_id=' + encodeURIComponent(laundryRequestId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        row.remove(); 
                    } else {
                        alert("Failed to delete the order. " + (data.message || ""));
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred.");
                });
            }
        });
    });
</script>

    </div>
</body>
</html>