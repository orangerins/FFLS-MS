-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2025 at 04:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ffls`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'Mark Amado', 'ffls123');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `middle_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `contact_number` varchar(11) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `barangay` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `middle_name`, `last_name`, `contact_number`, `street`, `barangay`, `city`, `province`, `zip_code`, `email`, `username`, `password`) VALUES
(1, 'Orange', 'Suarez', 'Mercado', '09754776042', 'Purok 16 Zone 1', 'Palao', 'Iligan City', 'Lanao Del Norte', '9200', 'orangesuarez.mercado@my.smciligan.edu.ph', 'orange', 'orange123'),
(2, 'Jhochelle', 'Paradela', 'Montante', '09620506114', '4th east Extension ', 'Tubod', 'Iligan City', 'Lanao Del Norte', '9200', 'Montante.jhochelle@gmail.com', 'jhochelle', 'jhochelle123'),
(3, 'Princess Janine', 'Alvarico', 'Bongon', '09563381225', 'Purok Pula', 'Villa Verde', 'Iligan City', 'Lanao Del Norte', '9200', 'princessjaninealvarico.bongon@my.smciligan.edu.ph', 'janine', 'janine123'),
(4, 'Nicole Marie', 'Pajo', 'Bihag', '09932262392', '3-A', 'Hinaplanon', 'Iligan City', 'Lanao Del Norte', '9200', 'juliannicolebihag@gmail.com', 'nicole', 'nicole123'),
(5, 'Janah', 'Alibangbang', 'Baltazar', '09617249628', 'Balite Drive', 'Suarez', 'Iligan City', 'Lanao Del Norte', '9200', 'janahalibangbang.baltazar@my.smciligan.edu.ph', 'janah', 'janah123'),
(6, 'Kristine Jane', 'Delatado', 'Eusebio', '09102803856', 'Zone 2', 'Hindang', 'Iligan City', 'Lanao Del Norte', '9200', 'kristinejanedelatado.eusebio@my.smciligan.edu.ph', 'kristine', 'kristine123'),
(7, 'Christian James', 'Autida', 'Usman', '09552891301', 'Purok 1 ', 'Tambacan', 'Iligan City', 'Lanao Del Norte', '9200', 'chan.usman@gmail.com', 'chan', 'chan123'),
(8, 'Rusthine Shane', 'Macaliag', 'Micabalo', '09530426377', 'Purok 6', 'Saray', 'Iligan City', 'Lanao Del Norte', '9200', 'rushtineshane.micabalo@gmail.com', 'rusthine', 'rusthine123'),
(9, 'Angel Faith', 'Denolan', 'Saraña', '09679144526', 'Purok 7', 'Ubaldo Laya ', 'Iligan City', 'Lanao Del Norte', '9200', 'a.faithsarana@gmail.com', 'angel', 'angel123');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_id`, `item_name`, `category`, `quantity`, `price`) VALUES
(5, 'Plastic Bag', 'Packaging', 278, 2.00),
(6, 'Liquid Detergent', 'Cleaning Supplies', 278, 10.00),
(7, 'Fabric Conditioner', 'Cleaning Supplies', 278, 10.00);

-- --------------------------------------------------------

--
-- Table structure for table `laundry_request`
--

CREATE TABLE `laundry_request` (
  `laundry_request_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `date_placed` date DEFAULT NULL,
  `status` enum('Pending','Washing','Drying','Folding','Ready for Pick-up','Completed') DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `weight` decimal(10,2) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `wash_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `laundry_request`
--

INSERT INTO `laundry_request` (`laundry_request_id`, `item_id`, `admin_id`, `date_placed`, `status`, `total_price`, `weight`, `customer_id`, `wash_type`) VALUES
(1, NULL, NULL, '2025-05-17', 'Pending', 382.00, 16.00, 1, 'full-service'),
(2, NULL, NULL, '2025-05-18', 'Pending', 60.00, 8.00, 2, 'wash-only'),
(3, NULL, NULL, '2025-05-18', 'Pending', 380.00, 16.00, 3, 'full-service'),
(4, NULL, NULL, '2025-05-18', 'Pending', 50.00, 8.00, 4, 'wash-only'),
(5, NULL, NULL, '2025-05-19', 'Washing', 120.00, 16.00, 5, 'wash-only'),
(6, NULL, NULL, '2025-05-17', 'Pending', 200.00, 8.00, 6, 'full-service'),
(7, NULL, NULL, '2025-05-17', 'Pending', 360.00, 16.00, 7, 'full-service'),
(8, NULL, NULL, '2025-05-17', 'Pending', 380.00, 16.00, 8, 'full-service'),
(9, NULL, NULL, '2025-05-18', 'Pending', 190.00, 8.00, 9, 'full-service');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `laundry_request_id` int(11) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `laundry_request_id`, `amount_paid`, `payment_date`, `payment_method`) VALUES
(1, 1, 382.00, '2025-05-17', 'Cash'),
(2, 2, 60.00, '2025-05-18', 'Cash'),
(4, 3, 380.00, '2025-05-18', 'Cash'),
(5, 4, 50.00, '2025-05-18', 'Cash'),
(6, 5, 120.00, '2025-05-19', 'Cash'),
(7, 6, 200.00, '2025-05-17', 'Cash'),
(8, 7, 360.00, '2025-05-17', 'Cash'),
(9, 8, 380.00, '2025-05-17', 'Cash'),
(10, 9, 190.00, '2025-05-18', 'Cash');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `laundry_request`
--
ALTER TABLE `laundry_request`
  ADD PRIMARY KEY (`laundry_request_id`),
  ADD KEY `fk_admin` (`admin_id`),
  ADD KEY `fk_item_id` (`item_id`),
  ADD KEY `fk_customer_request` (`customer_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `fk_laundry_request_id` (`laundry_request_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `laundry_request`
--
ALTER TABLE `laundry_request`
  MODIFY `laundry_request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `laundry_request`
--
ALTER TABLE `laundry_request`
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`),
  ADD CONSTRAINT `fk_customer_request` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `fk_item_id` FOREIGN KEY (`item_id`) REFERENCES `inventory` (`item_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_laundry_request_id` FOREIGN KEY (`laundry_request_id`) REFERENCES `laundry_request` (`laundry_request_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
