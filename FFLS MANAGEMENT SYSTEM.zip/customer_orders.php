<?php
session_start();
include('db_connection.php');
include('subtract_inventory_order.php');

if (!isset($_SESSION['client_logged_in']) || !$_SESSION['client_logged_in']) {
    header("Location: customer_login.php");
    exit();
}

$customerId = $_SESSION['client_id'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $weight = isset($_POST['weight']) ? (float)$_POST['weight'] : 0;
    $washType = $_POST['wash_type'] ?? '';
    $datePlaced = !empty($_POST['date_placed']) ? $_POST['date_placed'] : date('Y-m-d');


    if ($washType === "wash-only") {
        $totalPrice = ($weight <= 8) ? 50 : ceil($weight / 8) * 50;
    } elseif ($washType === "full-service") {
        $totalPrice = ($weight <= 8) ? 180 : ceil($weight / 8) * 180;
    } else {
        $totalPrice = 0;
    }

    $addOns = 0;
    if (!empty($_POST['addons']) && is_array($_POST['addons'])) {
        $addonIds = array_map('intval', $_POST['addons']);
        $placeholders = implode(',', array_fill(0, count($addonIds), '?'));
        $types = str_repeat('i', count($addonIds));

        $sql = "SELECT price FROM inventory WHERE item_id IN ($placeholders)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$addonIds);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $addOns += (float)$row['price'];
        }

        $stmt->close();
    }

    $totalPrice += $addOns;

 
    $sql = "INSERT INTO laundry_request (customer_id, date_placed, status, total_price, weight, wash_type) VALUES (?, ?, 'Pending', ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isdss", $customerId, $datePlaced, $totalPrice, $weight, $washType);

    if ($stmt->execute()) {

        subtractOrderInventory($weight, $_POST['addons'] ?? []);

        header("Location: customer_orders.php?success=1");
        exit();
    } else {
        echo "Order error: " . $stmt->error;
    }

    $stmt->close();
}


$searchTerm = $_GET['search'] ?? '';

if ($searchTerm !== '') {
    $searchTerm = "%{$searchTerm}%";
    $sql = "SELECT * FROM laundry_request WHERE customer_id = ? AND (wash_type LIKE ? OR status LIKE ?) ORDER BY date_placed DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $customerId, $searchTerm, $searchTerm);
} else {
    $sql = "SELECT * FROM laundry_request WHERE customer_id = ? ORDER BY date_placed DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customerId);
}
$stmt->execute();
$result = $stmt->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFold Laundry Services - Orders</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-top: 70px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.shift {
            margin-left: 260px;
        }

        .orders-controls {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            align-items: center;
        }

        #add-order-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background-color: #82b8ef;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        #add-order-btn img {
            width: 18px;
            height: 18px;
        }

        #search-bar {
            padding: 8px;
            width: 200px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #96c7f9;
        }

        #add-order-form {
            margin-top: 20px;
            background: #ffffff;
            padding: 25px;
            border-radius: 8px;
            width: 400px;
            margin: 0 auto;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        #add-order-form input, #add-order-form select {
            margin-bottom: 15px;
            padding: 10px;
            width: 100%;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        #add-order-form label {
            font-size: 14px;
            margin-bottom: 5px;
        }

        #add-order-form button {
            background-color: #82b8ef;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
            font-size: 16px;
        }

        #cancel-order-btn {
            background-color: #f44336;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
        }

        .status-pending {
            color: rgb(201, 201, 18);
            text-align: center;
            font-weight: bold;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            width: 450px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-content h3 {
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }

        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }

        .checkbox-group input {
            transform: scale(1.2);
        }

        .total-payment {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }

        .close {
            background-color: #f44336;
            color: white;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            border-radius: 5px;
            font-size: 16px;
        }
         #viewOrderModal .modal-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            width: 400px;
            text-align: left;
        }

        #viewOrderModal .modal-content h3 {
            margin-bottom: 20px;
            color: #333;
        }

        #viewOrderModal .modal-content p {
            margin-bottom: 10px;
            font-size: 14px;
        }

        #close-view-btn {
            margin-top: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;">
            <button id="menu-btn"><img src="m-icon.png" alt="Menu"></button>
        </div>
    </header>

    <div class="sidebar" id="sidebar">
        <ul>
        <li><img src="d-icon.png" alt="Dashboard"><a href="customer_dashboard.php">Dashboard</a></li>
        <li><img src="O-icon.png" alt="Orders"><a href="customer_orders.php">Orders</a></li>
        <li class="active"><img src="p-icon.png" alt="Payments"><a href="customer_payment.php">Payments</a></li>
    </ul>
    </div>

    <div class="content" id="content">
        <h2>Orders</h2>
<div class="orders-controls">
    <button id="add-order-btn"><img src="add-icon.png" alt="Add Order"> Add Order</button>
</div>
<input type="text" id="search-bar" placeholder="Search Orders..." value="<?php echo htmlspecialchars($_GET['search'] ?? '', ENT_QUOTES); ?>" />


<table id="orders-table">
    <thead>
        <tr>
            <th>Date Placed</th>
            <th>Weight (kg)</th>
            <th>Total Price (PHP)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="orders-body">
        <?php 
        if (!empty($orders)) {
            foreach ($orders as $order): 
                $datePlaced = htmlspecialchars($order['date_placed'] ?? 'N/A');
                $weight = htmlspecialchars($order['weight'] ?? 'N/A');
                $totalPrice = isset($order['total_price']) ? number_format($order['total_price'], 2) : '0.00';
                $status = htmlspecialchars($order['status'] ?? 'Pending');
                $washType = htmlspecialchars($order['wash_type'] ?? '');
        ?>
            <tr>
                <td><?= $datePlaced ?></td>
                <td><?= $weight ?></td>
                <td>₱<?= $totalPrice ?></td>
                <td class="status-pending"><?= $status ?></td>
                <td>
                    <button onclick="viewOrder(
                        decodeURIComponent('<?= rawurlencode($datePlaced) ?>'),
                        decodeURIComponent('<?= rawurlencode($weight) ?>'),
                        '₱<?= $totalPrice ?>',
                        decodeURIComponent('<?= rawurlencode($washType) ?>')
                    )">View</button>
                </td>
            </tr>
        <?php 
            endforeach;
        } else {
            echo '<tr><td colspan="5">No orders found</td></tr>';
        }
        ?>
    </tbody>
</table>

<div id="viewOrderModal" class="modal">
    <div class="modal-content">
        <h3>Order Details</h3>
        <p><strong>Date Placed:</strong> <span id="view-date"></span></p>
        <p><strong>Weight:</strong> <span id="view-weight"></span> kg</p>
        <p><strong>Total Price:</strong> <span id="view-price"></span></p>
        <p><strong>Wash Type:</strong> <span id="view-type"></span></p>
        <button id="close-view-btn" onclick="closeViewModal()">Close</button>
    </div>
</div>


<div class="modal" id="orderModal">
    <div class="modal-content">
        <h3>Add New Order</h3>
        <form id="add-order-form" method="POST">
            <label for="wash-type">Wash Type:</label>
            <select id="wash-type" name="wash_type" required>
                <option value="wash-only">Wash Only (₱50 per 8 kg)</option>
                <option value="full-service">Full Service (₱180 per 8 kg)</option>
            </select>

            <label for="order-weight">Weight (kg):</label>
            <input type="number" id="order-weight" name="weight" required min="1">

            <label for="order-date">Date Placed:</label>
            <input type="date" id="order-date" name="date_placed" required>

           <label>Add-ons (Select up to 3):</label>
            <div class="checkbox-group">
            <?php
            require 'db_connection.php'; 

            $sql = "SELECT item_id, item_name, price FROM inventory WHERE category = 'Cleaning Supplies'";
            $result = $conn->query($sql);
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = 'addon-' . $row['item_id'];
                    echo "<label><input type='checkbox' id='$id' name='addons[]' value='{$row['item_id']}' data-price='{$row['price']}'> {$row['item_name']} (₱" . number_format($row['price'], 2) . ")</label>";
                }
            }else {
                echo "<p>No add-ons available.</p>";
            }
            ?>
            </div>
            <div class="total-payment">Total Payment: ₱<span id="total-payment">0.00</span></div>

            <button type="submit">Add Order</button>
            <button type="button" id="cancel-order-btn" onclick="closeOrderModal()">Cancel</button>
        </form>
    </div>
</div>

<script>

    const menuBtn = document.getElementById('menu-btn');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        content.classList.toggle('shift');
    });
    const searchBar = document.getElementById('search-bar');
let typingTimer;
const typingInterval = 500; 

searchBar.addEventListener('input', () => {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    const searchTerm = searchBar.value.trim();
    const url = new URL(window.location.href);
    if (searchTerm) {
      url.searchParams.set('search', searchTerm);
    } else {
      url.searchParams.delete('search');
    }
    window.location.href = url.toString();
  }, typingInterval);
});

    function viewOrder(date, weight, price, type) {
        document.getElementById('view-date').textContent = date;
        document.getElementById('view-weight').textContent = weight;
        document.getElementById('view-price').textContent = price;
        document.getElementById('view-type').textContent = type;
        document.getElementById('viewOrderModal').style.display = 'flex';
    }

    function closeViewModal() {
        document.getElementById('viewOrderModal').style.display = 'none';
    }

    window.addEventListener('click', function(e) {
        const viewModal = document.getElementById('viewOrderModal');
        if (e.target === viewModal) {
            viewModal.style.display = 'none';
        }
    });


    const addOrderBtn = document.getElementById('add-order-btn');
    const orderModal = document.getElementById('orderModal');
    const cancelOrderBtn = document.getElementById('cancel-order-btn');

    addOrderBtn.addEventListener('click', () => {
        orderModal.style.display = 'flex';
        updateTotal();
    });

    function closeOrderModal() {
        orderModal.style.display = 'none';
    }

    window.addEventListener('click', function(event) {
        if (event.target === orderModal) {
            closeOrderModal();
        }
    });


    const weightInput = document.getElementById("order-weight");
    const washTypeSelect = document.getElementById("wash-type");
    const addonCheckboxes = document.querySelectorAll("input[type='checkbox'][name='addons[]']");

    weightInput.addEventListener("input", updateTotal);
    washTypeSelect.addEventListener("change", updateTotal);
    addonCheckboxes.forEach(checkbox => checkbox.addEventListener("change", updateTotal));

    function updateTotal() {
        const weight = parseFloat(weightInput.value) || 0;
        const washType = washTypeSelect.value;
        const checkedAddons = Array.from(addonCheckboxes).filter(cb => cb.checked);

        let total = 0;


        if (washType === "wash-only") {
            total = 50 * Math.ceil(weight / 8);
        } else if (washType === "full-service") {
            total = 180 * Math.ceil(weight / 8);
        }


        checkedAddons.forEach(cb => {
            const price = parseFloat(cb.dataset.price);
            if (!isNaN(price)) total += price;
        });

        document.getElementById("total-payment").textContent = total.toFixed(2);
    }
</script>
</body>
</html>
