<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}
$adminUsername = $_SESSION['admin_username'];

include('db_connection.php');
$query = "
    SELECT customer.*, COUNT(laundry_request.laundry_request_id) AS total_orders
    FROM customer
    LEFT JOIN laundry_request ON customer.customer_id = laundry_request.customer_id
    GROUP BY customer.customer_id
";
$result = mysqli_query($conn, $query);

$customers = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $customers[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin - Customers | FreshFold Laundry Services</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
    text-decoration: none;
}
body {
    background: #f8f9fa;
    display: flex;
    flex-direction: column;
    height: 100vh;
    overflow: hidden;
}
header {
    background: #82b8ef;
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 1000;
    height: 60px;
}
.logo-menu {
    display: flex;
    align-items: center;
    gap: 10px;
}
#menu-btn {
    background: none;
    border: none;
    cursor: pointer;
}
#menu-btn img {
    width: 25px;
    height: 25px;
}
.user-profile {
    display: flex;
    align-items: center;
    gap: 5px;
    position: relative;
}
.user-profile img {
    width: 18px;
    height: 18px;
    cursor: pointer;
}
.user-profile span {
    font-size: 14px;
}
.sidebar {
    background: #96c7f9;
    width: 240px;
    height: 100vh;
    position: fixed;
    left: -240px;
    top: 55px;
    padding-top: 10px;
    border-right: 1px solid #ccc;
    transition: left 0.3s ease-in-out;
}
.sidebar.active {
    left: 0;
}
.sidebar ul {
    list-style: none;
    padding: 0;
}
.sidebar ul li {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
}
.sidebar ul li img {
    width: 24px;
    height: 24px;
}
.sidebar ul li a {
    color: white;
    font-size: 16px;
}
.content {
    margin-left: 20px;
    margin-top: 60px;
    padding: 10px;
    transition: margin-left 0.3s ease-in-out;
}
.content.shift {
    margin-left: 260px;
}
h2 {
    margin-top: 20px;
    color: #333;
}
.controls {
    margin: 20px 0 10px 0;
}
.controls input {
    padding: 6px 10px;
    border: none;
    border-radius: 15px;
    background: #f1f5ff;
    font-size: 14px;
    width: 300px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
th, td {
    padding: 10px;
    text-align: left;
    border: 1px solid #ccc;
}
th {
    background-color: #96c7f9;
    color: white;
}
.logout-box {
    position: absolute;
    top: 30px;
    right: 0;
    background-color: white;
    border: 1px solid #ccc;
    border-radius: 5px;
    display: none;
    z-index: 1001;
}
.logout-box a {
    display: block;
    padding: 10px 20px;
    color: #165a91;
    font-size: 14px;
}
.logout-box a:hover {
    background-color: #f0f0f0;
}
</style>
</head>
<body>
<header>
    <div class="logo-menu">
        <img src="FFLSlogo.png" alt="FreshFold Logo" style="height: 50px;" />
        <button id="menu-btn"><img src="m-icon.png" alt="Menu" /></button>
    </div>
</header>

<div class="sidebar" id="sidebar">
    <ul>
        <li><img src="d-icon.png" alt="Dashboard Icon" /><a href="admin-dashboard.php">Dashboard</a></li>
        <li><img src="O-icon.png" alt="Orders Icon" /><a href="admin-orders.php">Orders</a></li>
        <li><img src="c-icon.png" alt="Customers Icon" /><a href="admin-customers.php">Customers</a></li>
        <li><img src="i-icon.png" alt="Inventory Icon" /><a href="admin-inventory.php">Inventory</a></li>
        <li><img src="p-icon.png" alt="Payments Icon" /><a href="admin-payments.php">Payments</a></li>
    </ul>
</div>

<div class="content" id="main-content">
    <h2>Customer List</h2>
    <div class="controls">
        <input type="text" placeholder="Search by name or email" id="searchInput" />
    </div>
    <table>
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone #</th>
                <th>Address</th>
                <th>Total Orders</th>
            </tr>
        </thead>
        <tbody id="customerTableBody">
            <?php foreach ($customers as $cust): ?>
            <tr>
                <td><?= htmlspecialchars($cust['customer_id']) ?></td>
                <td><?= htmlspecialchars($cust['first_name'] . ' ' . $cust['middle_name'] . ' ' . $cust['last_name']) ?></td>
                <td><?= htmlspecialchars($cust['email']) ?></td>
                <td><?= htmlspecialchars($cust['contact_number']) ?></td>
                <td><?= htmlspecialchars($cust['street'] . ', ' . $cust['barangay'] . ', ' . $cust['city'] . ', ' . $cust['province'] . ', ' . $cust['zip_code']) ?></td>
                <td><?= htmlspecialchars($cust['total_orders']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
const menuBtn = document.getElementById('menu-btn');
const sidebar = document.getElementById('sidebar');
const content = document.getElementById('main-content');
const profileIcon = document.getElementById('profile-icon');
const logoutBox = document.getElementById('logout-box');
const searchInput = document.getElementById('searchInput');


menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    content.classList.toggle('shift');
});

if (profileIcon && logoutBox) {
    profileIcon.addEventListener('click', () => {
        logoutBox.style.display = logoutBox.style.display === 'block' ? 'none' : 'block';
    });

    window.addEventListener('click', (e) => {
        if (!e.target.closest('.user-profile')) {
            logoutBox.style.display = 'none';
        }
    });
}


searchInput.addEventListener('input', () => {
    const filter = searchInput.value.trim().toLowerCase();
    const rows = document.querySelectorAll('#customerTableBody tr');

    rows.forEach(row => {
        const customerId = row.children[0].textContent.trim().toLowerCase();
        const fullName = row.children[1].textContent.trim().toLowerCase();
        const email = row.children[2].textContent.trim().toLowerCase();
        const contactNumber = row.children[3].textContent.trim().toLowerCase();

        const nameParts = fullName.split(' ');
        const nameMatch = nameParts.some(part => part.includes(filter));

        if (
            customerId.includes(filter) ||
            fullName.includes(filter) ||
            nameMatch ||
            email.includes(filter) ||
            contactNumber.includes(filter)
        ) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>
</body>
</html>