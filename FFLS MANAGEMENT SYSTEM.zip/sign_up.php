<?php
session_start();
include('db_connection.php');

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $insert_admin = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";

    if (mysqli_query($conn, $insert_admin)) {
        $success = true;
        $message = 'Admin account created successfully! You can now log in.';
    } else {
        $error = 'Error creating admin account: ' . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign Up</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            overflow: auto;
            flex-wrap: wrap;
        }

        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }

        .right-side {
            flex: 1;
            max-width: 500px;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            overflow-y: auto;
        }

        .logo {
            width: 230px;
            margin: 20px 0;
        }

        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 350px;
            text-align: left;
        }

        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
        }

        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }

        .signup {
            background-color: #6a9ff8;
            color: white;
        }

        .back-login {
            background-color: white;
            border: 1px solid #6a9ff8;
            color: #6a9ff8;
        }

        .back-login:hover {
            background-color: #6a9ff8;
            color: white;
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .left-side {
                display: none;
            }

            .right-side {
                width: 100%;
                max-width: none;
            }
        }
    </style>
</head>
<body>
<div class="left-side"></div>
<div class="right-side">
    <img src="FFLSlogo.png" class="logo" alt="Logo">
    <div class="input-container">
        <h2>Admin Sign Up</h2>
        <?php if ($error): ?>
            <p style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p style="color:green; margin-bottom:10px;"><?php echo htmlspecialchars($message); ?></p>
            <div class="buttons">
                <button class="back-login" onclick="window.location.href='admin_login.php'">Go to Admin Login</button>
            </div>
        <?php else: ?>
            <form method="POST" action="">
                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <button class="signup" type="submit">Sign Up</button>
            </form>
            <div class="buttons">
                <button class="back-login" onclick="window.location.href='admin_login.php'">Back to Admin Login</button>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>