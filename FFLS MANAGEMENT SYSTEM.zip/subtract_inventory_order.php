<?php
require 'db_connection.php';

function subtractOrderInventory($weight, $selectedAddons) {
    global $conn;

    $totalAddOnCost = 0;
    $unitsToSubtract = floor($weight / 8) * 2;

    if ($unitsToSubtract <= 0) {
        
        return 0;
    }


    $baseItems = [];


    $sqlBaseCleaning = "SELECT item_name FROM inventory WHERE category = 'Cleaning Supplies' AND (item_name LIKE '%Detergent%' OR item_name LIKE '%Conditioner%')";
    $resultBaseCleaning = $conn->query($sqlBaseCleaning);
    while ($row = $resultBaseCleaning->fetch_assoc()) {
        $baseItems[] = $row['item_name'];
    }

   
    $sqlBasePackaging = "SELECT item_name FROM inventory WHERE category = 'Packaging'";
    $resultBasePackaging = $conn->query($sqlBasePackaging);
    while ($row = $resultBasePackaging->fetch_assoc()) {
        $baseItems[] = $row['item_name'];
    }


    foreach ($baseItems as $item) {
        $stmt = $conn->prepare("UPDATE inventory SET quantity = quantity - ? WHERE item_name = ?");
        if (!$stmt) {
     
            continue;
        }
        $stmt->bind_param("is", $unitsToSubtract, $item);
        $stmt->execute();
        $stmt->close();
    }


    if (empty($baseItems)) {
     
        $sqlAddons = "SELECT item_name, price FROM inventory WHERE category = 'Cleaning Supplies'";
        $result = $conn->query($sqlAddons);
        $addons = [];
        while ($row = $result->fetch_assoc()) {
            $addons[$row['item_name']] = $row['price'];
        }
    } else {
  
        $placeholders = implode(',', array_fill(0, count($baseItems), '?'));
        $types = str_repeat('s', count($baseItems));

        $sqlAddons = "SELECT item_name, price FROM inventory WHERE category = 'Cleaning Supplies' AND item_name NOT IN ($placeholders)";
        $stmt = $conn->prepare($sqlAddons);
        if (!$stmt) {

            $addons = [];
        } else {
            $stmt->bind_param($types, ...$baseItems);
            $stmt->execute();
            $result = $stmt->get_result();

            $addons = [];
            while ($row = $result->fetch_assoc()) {
                $addons[$row['item_name']] = $row['price'];
            }
            $stmt->close();
        }
    }


    if (!is_array($selectedAddons)) {
        $selectedAddons = [];
    }

    foreach ($selectedAddons as $addon) {
        if (isset($addons[$addon])) {
            $stmt = $conn->prepare("UPDATE inventory SET quantity = quantity - 1 WHERE item_name = ?");
            if (!$stmt) {
                continue;
            }
            $stmt->bind_param("s", $addon);
            $stmt->execute();
            $stmt->close();

            $totalAddOnCost += $addons[$addon];
        }
    }

    return $totalAddOnCost;
}
?>
