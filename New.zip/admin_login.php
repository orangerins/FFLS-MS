<?php
session_start();
include('db_connection.php');

$error = '';

if (isset($_SESSION['admin_logged_in'])) {
    header('Location: admin-dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Get plain password

    $sql = "SELECT admin_id, username, password FROM admin WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        // Directly compare the entered password with the database password
        if ($password == $row['password']) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $row['admin_id'];
            $_SESSION['admin_username'] = $row['username'];
            header("Location: admin-dashboard.php");
            exit();
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }

        .right-side {
            width: 30%;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            text-align: center;
        }

        .logo {
            width: 230px;
            margin-bottom: 20px;
        }

        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 350px;
            text-align: left;
        }

        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
        }

        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }

        .login {
            background-color: #6a9ff8;
            color: white;
        }

        .signup {
            background-color: white;
            border: 1px solid #6a9ff8;
            color: #6a9ff8;
        }

        .signup:hover {
            background-color: #6a9ff8;
            color: white;
        }
    </style>
</head>
<body>
    <div class="left-side"></div>
    <div class="right-side">
        <img src="FFLSlogo.png" alt="FreshFold Logo" class="logo">
        <div class="input-container">
            <h2>Admin Login</h2>
            <?php if ($error): ?>
                <p style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
            <form method="POST" action="">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter username" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter password" required>

                <div class="buttons">
                    <button type="button" class="signup" onclick="window.location.href='admin_sign_up.php'">Sign Up</button>
                    <button type="submit" class="login">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>