<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $washType = $_POST['wash_type'];
    $weight = floatval($_POST['weight']);
    $status = $_POST['status'];
    $datePlaced = $_POST['date_placed'];
    $addonsSelected = isset($_POST['addons']) ? $_POST['addons'] : []; // Array of selected addon IDs

    $totalPayment = 0;
    $customerId = null;

    // Check if customer exists (same as before)
    $nameParts = explode(' ', trim($customerName));
    $firstName = isset($nameParts[0]) ? mysqli_real_escape_string($conn, $nameParts[0]) : '';
    $lastName = isset($nameParts[count($nameParts) - 1]) ? mysqli_real_escape_string($conn, $nameParts[count($nameParts) - 1]) : '';

    $checkCustomerSql = "SELECT customer_id FROM customer WHERE first_name = ? AND last_name = ?";
    $checkCustomerStmt = $conn->prepare($checkCustomerSql);
    $checkCustomerStmt->bind_param("ss", $firstName, $lastName);
    $checkCustomerStmt->execute();
    $checkCustomerResult = $checkCustomerStmt->get_result();

    if ($checkCustomerResult->num_rows > 0) {
        $customerRow = $checkCustomerResult->fetch_assoc();
        $customerId = $customerRow['customer_id'];
    } else {
        // Create a new customer
        $insertCustomerSql = "INSERT INTO customer (first_name, last_name) VALUES (?, ?)";
        $insertCustomerStmt = $conn->prepare($insertCustomerSql);
        $insertCustomerStmt->bind_param("ss", $firstName, $lastName);
        if ($insertCustomerStmt->execute()) {
            $customerId = $conn->insert_id;
        } else {
            echo "<script>alert('Error creating new customer: " . $insertCustomerStmt->error . "'); window.history.back();</script>";
            exit();
        }
        $insertCustomerStmt->close();
    }
    $checkCustomerStmt->close();

    // Calculate Base Price
    if ($washType === 'Wash Only' && is_numeric($weight)) {
        $totalPayment = ceil($weight / 8) * 50;
    } elseif ($washType === 'Full Service' && is_numeric($weight)) {
        $totalPayment = ceil($weight / 8) * 180;
    }

    // Process Add-ons to calculate total payment
    if (!empty($addonsSelected)) {
        $addonPriceSql = "SELECT price FROM inventory WHERE item_id IN (" . implode(',', array_map('intval', $addonsSelected)) . ")";
        $addonPriceResult = $conn->query($addonPriceSql);
        if ($addonPriceResult && $addonPriceResult->num_rows > 0) {
            while ($addonPriceRow = $addonPriceResult->fetch_assoc()) {
                $totalPayment += $addonPriceRow['price'];
            }
        }
    }

    // Insert New Order (without addon details)
    $insertOrderSql = "INSERT INTO laundry_request (customer_id, date_placed, status, total_price, weight, wash_type) VALUES (?, ?, ?, ?, ?, ?)";
    $insertOrderStmt = $conn->prepare($insertOrderSql);
    $insertOrderStmt->bind_param("isssds", $customerId, $datePlaced, $status, $totalPayment, $weight, $washType);

    if ($insertOrderStmt->execute()) {
        echo "<script>alert('Order added successfully!'); window.location.href='admin-orders.php';</script>";
    } else {
        echo "<script>alert('Error adding order: " . $insertOrderStmt->error . "'); window.history.back();</script>";
    }
    $insertOrderStmt->close();

    $conn->close();
} else {
    echo "Invalid request method.";
}
?>