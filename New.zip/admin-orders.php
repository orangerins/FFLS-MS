<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$adminUsername = $_SESSION['admin_username'];

// Function to fetch all orders
function getAllOrders($conn) {
    $sql = "SELECT lr.laundry_request_id AS order_id,
                   c.customer_id,
                   c.first_name,
                   c.last_name,
                   lr.date_placed AS order_date,
                   lr.total_price AS total_amount,
                   lr.status
            FROM laundry_request lr
            JOIN customer c ON lr.customer_id = c.customer_id
            ORDER BY lr.date_placed DESC";
    $result = $conn->query($sql);
    $orders = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    return $orders;
}

// Function to update order status
if (isset($_POST['update_status']) && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $orderId = intval($_POST['order_id']);
    $newStatus = mysqli_real_escape_string($conn, $_POST['new_status']);

    $updateSql = "UPDATE laundry_request SET status = ? WHERE laundry_request_id = ?";
    $updateStmt = $conn->prepare($updateSql);
    if ($updateStmt) {
        $updateStmt->bind_param("si", $newStatus, $orderId);
        if ($updateStmt->execute()) {
            echo "success"; // Indicate successful update
        } else {
            echo "error: " . $updateStmt->error;
        }
        $updateStmt->close();
    } else {
        echo "error: " . $conn->error;
    }
    exit(); // Stop further execution after processing the update
}

$orders = getAllOrders($conn);

// Fetch available add-ons (both soap and fabric conditioner) - FIXED QUERY
$addonsSql = "SELECT item_id, item_name, price FROM inventory WHERE category = 'Cleaning Supplies' AND (item_name LIKE '%Soap%' OR item_name LIKE '%Fabric Conditioner%') AND quantity > 0 ORDER BY item_name";
$addonsResult = $conn->query($addonsSql);
$addons = [];
if ($addonsResult && $addonsResult->num_rows > 0) {
    while ($row = $addonsResult->fetch_assoc()) {
        $addons[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders - FreshFold Laundry Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            text-decoration: none;
        }

        body {
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow-x: auto; /* Added for potential horizontal scroll on smaller screens */
        }

        header {
            background: #82b8ef;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            height: 60px;
        }

        .logo-menu {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #menu-btn {
            background: none;
            border: none;
            cursor: pointer;
            color: white;
            font-size: 20px;
        }

        #menu-btn img {
            width: 25px;
            height: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 5px;
            position: relative;
        }

        .user-profile img {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .user-profile span {
            font-size: 14px;
        }

        .sidebar {
            background: #96c7f9;
            width: 240px;
            height: 100vh;
            position: fixed;
            left: -240px;
            top: 60px;
            padding-top: 10px;
            border-right: 1px solid #ccc;
            transition: left 0.3s ease-in-out;
            overflow-y: auto;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .sidebar ul li img {
            width: 24px;
            height: 24px;
        }

        .sidebar ul li a {
            color: white;
            font-size: 16px;
        }

        .content {
            margin-left: 20px;
            margin-top: 80px;
            padding: 20px;
            transition: margin-left 0.3s ease-in-out;
            overflow-y: auto;
            height: calc(100vh - 80px);
        }

        .content.shift {
            margin-left: 260px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 button {
            background-color: #96c7f9; /* Changed to blue */
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        h1 button:hover {
            background-color: #82b8ef; /* Slightly darker blue on hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #96c7f9;
            font-weight: bold;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .action-links {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .action-link {
            color: #82b8ef;
            cursor: pointer;
        }

        .action-link.delete {
            color: #f44336;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .status-select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: white;
        }

        .logout-box {
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: none;
            z-index: 1001;
        }

        .logout-box a {
            display: block;
            padding: 10px 20px;
            color: #165a91;
            text-decoration: none;
            font-size: 14px;
        }

        .logout-box a:hover {
            background-color: #f0f0f0;
        }

        /* Modal Styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
            border-radius: 5px;
            position: relative;
        }

        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-content label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .modal-content input[type=text],
        .modal-content select,
        .modal-content input[type=date],
        .modal-content input[type=number] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .modal-content .buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .modal-content .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .modal-content .buttons button.save {
            background-color: #5cb85c;
            color: white;
        }

        .modal-content .buttons button.save:hover {
            background-color: #4cae4c;
        }

        .modal-content .buttons button.cancel {
            background-color: #f44336;
            color: white;
        }

        .modal-content .buttons button.cancel:hover {
            background-color: #d32f2f;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        $(document).ready(function() {
            // Function to calculate total payment
            function calculateTotalPayment() {
                const washType = <span class="math-inline">\('\#wash\_type'\)\.val\(\);
const weight \= parseFloat\(</span>('#weight').val()) || 0;
                let basePrice = 0;
                let addonCost = 0;

                if (washType === 'Wash Only') {
                    basePrice = Math.ceil(weight / 8) * 50;
                } else if (washType === 'Full Service') {
                    basePrice = Math.ceil(weight / 8) * 180;
                }

                // Calculate add-on costs
                <span class="math-inline">\('input\[name\="addons\[\]"\]\:checked'\)\.each\(function\(\) \{
addonCost \+\= parseFloat\(</span>(this).data('price'));
                });

                const totalPayment = basePrice + addonCost;
                $('#total_payment').text(totalPayment.toFixed(2));
            }

            // Event listener for wash type and weight change
            $('#wash_type, #weight').on('change', calculateTotalPayment);

            // Event listener for add-on selection change
            $(document).on('change', 'input[name="addons[]"]', calculateTotalPayment);

            // Limit add-on selections to 3
            <span class="math-inline">\(document\)\.on\('change', 'input\[name\="addons\[\]"\]', function\(\) \{
const maxAddons \= 3;
if \(</span>('input[name="addons[]"]:checked').length > maxAddons) {
                    this.checked = false;
                    alert('You can select a maximum of ' + maxAddons + ' add-ons.');
                }
                calculateTotalPayment();
            });
        });
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <header>
        <div class="logo-menu">
            <img src="FFLSlogo.png" alt="Logo" style="height: 40px;">
            <button id="menu-btn">
                <img src="m-icon.png" alt="Menu">
            </button>
        </div>
        <div class="user-profile" id="logout-btn">
            <span>Admin</span>
            <img src="ad-icon.png" alt="Admin Icon">
            <div class="logout-box"id="logout-box">
                <a href="admin_login.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="sidebar" id="sidebar">
        <ul>
            <li><a href="admin-dashboard.php"><img src="d-icon.png"></i> Dashboard</a></li>
            <li class="active-menu"><a href="admin-orders.php"><img src="O-icon.png"></i> Orders</a></li>
            <li><a href="admin-customers.php"><img src="c-icon.png"></i> Customers</a></li>
            <li><a href="admin-inventory.php"><img src="i-icon.png"></i> Inventory</a></li>
            <li><a href="admin-Paymentsss.php"><img src="p-icon.png"></i> Payments</a></li>
            <li><a href="admin-reports.php"><img src="rp-icon.png"></i> Reports</a></li>
        </ul>
    </div>

    <div class="content" id="mainContent">
        <h1>
            Orders
            <button onclick="document.getElementById('addOrderModal').style.display='block'">Add New Order</button>
        </h1>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer ID</th>
                    <th>Customer Name</th>
                    <th>Date Placed</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan='7'>No orders found.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr id="order-row-<?php echo htmlspecialchars($order['order_id']); ?>">
                            <td><?php echo htmlspecialchars(sprintf('%04d', $order['order_id'])); ?></td>
                            <td><?php echo htmlspecialchars(sprintf('%03d', $order['customer_id'])); ?></td>
                            <td><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                            <td>₱<?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></td>
                            <td>
                                <select class="status-select" data-order-id="<?php echo htmlspecialchars($order['order_id']); ?>">
                                    <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="Washing" <?php if ($order['status'] == 'Washing') echo 'selected'; ?>>Washing</option>
                                    <option value="Drying" <?php if ($order['status'] == 'Drying') echo 'selected'; ?>>Drying</option>
                                    <option value="Folding" <?php if ($order['status'] == 'Folding') echo 'selected'; ?>>Folding</option>
                                    <option value="Ready for Pick-up" <?php if ($order['status'] == 'Ready for Pick-up') echo 'selected'; ?>>Ready for Pick-up</option>
                                    <option value="Completed" <?php if ($order['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
                                    <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                                </select>
                            </td>
                            <td>
                                <div class="action-links">
                                    <span class='action-link' onclick='viewOrderDetails(<?php echo htmlspecialchars($order['order_id']); ?>)'>View Details</span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div id="addOrderModal" class="modal">
            <div class="modal-content">
                <span onclick="document.getElementById('addOrderModal').style.display='none'" class="close-button">&times;</span>
                <h2>Add New Order</h2>
                <form id="addOrderForm" action="process_new_order.php" method="post">
                    <div>
                        <label for="customer_name">Customer Name:</label>
                        <input type="text" id="customer_name" name="customer_name" placeholder="Enter Customer Name" required>
                    </div>
                    <div>
                        <label for="wash_type">Wash Type:</label>
                        <select id="wash_type" name="wash_type">
                            <option value="Wash Only">Wash Only (₱50 per 8 kg)</option>
                            <option value="Full Service">Full Service (Wash, Dry, Fold - ₱180 per 8 kg)</option>
                        </select>
                    </div>
                    <div>
                        <label for="weight">Weight (kg):</label>
                        <input type="number" id="weight" name="weight" placeholder="Enter weight in kg" min="0" step="0.01">
                    </div>
                    <div>
                        <label for="status">Status:</label>
                        <select id="status" name="status">
                            <option value="Pending">Pending</option>
                            <option value="Washing">Washing</option>
                            <option value="Drying">Drying</option>
                            <option value="Folding">Folding</option>
                            <option value="Ready for Pick-up">Ready for Pick-up</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div>
                        <label for="date_placed">Date Placed:</label>
                        <input type="text" id="date_placed" name="date_placed" class="datepicker" placeholder="dd/mm/yyyy">
                    </div>
                    <div>
                        <label>Add-ons (Select up to 3):</label><br>
                        <?php if (!empty($addons)): ?>
                            <?php foreach ($addons as $addon): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="addons[]" value="<?php echo htmlspecialchars($addon['item_id']); ?>" data-price="<?php echo htmlspecialchars($addon['price']); ?>">
                                    <label class="form-check-label" for="addon_<?php echo htmlspecialchars($addon['item_id']); ?>">
                                        <?php echo htmlspecialchars($addon['item_name'] . ' (₱' . number_format($addon['price'], 2) . ')'); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No add-ons available in inventory.</p>
                        <?php endif; ?>
                    </div>
                    <p><b>Total Payment: ₱<span id="total_payment">0.00</span></b></p>
                    <div class="buttons">
                        <button type="submit" class="save">Save</button>
                        <button type="button" class="cancel" onclick="document.getElementById('addOrderModal').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <div id="order-details-modal" class="modal" style="display: none;">
            <div class="modal-content">
                <span onclick="closeModal('order-details-modal')" style="float: right; cursor: pointer;">&times;</span>
                <h2>Order Details</h2>
                <div id="order-details-content">
                    </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('menu-btn').addEventListener('click', function() {
                    document.getElementById('sidebar').classList.toggle('active');
                    document.getElementById('mainContent').classList.toggle('shift');
                });

                document.getElementById('logout-btn').addEventListener('click', function() {
                    document.getElementById('logout-box').style.display =
                        document.getElementById('logout-box').style.display === 'block' ? 'none' : 'block';
                });

                flatpickr(".datepicker", {
                    dateFormat: "d/m/Y",
                });
            });

            function viewOrderDetails(orderId) {
                alert('View details for Order ID: ' + orderId + ' (functionality to be implemented)');
            }

            function closeModal(modalId) {
                document.getElementById(modalId).style.display = 'none';
            }

            $(document).ready(function() {
                // Function to calculate total payment
                function calculateTotalPayment() {
                    const washType = $('#wash_type').val();
                    const weight = parseFloat($('#weight').val()) || 0;
                    let basePrice = 0;
                    let addonCost = 0;

                    if (washType === 'Wash Only') {
                        basePrice = Math.ceil(weight / 8) * 50;
                    } else if (washType === 'Full Service') {
                        basePrice = Math.ceil(weight / 8) * 180;
                    }

                    // Calculate add-on costs
                    $('input[name="addons[]"]:checked').each(function() {
                        addonCost += parseFloat($(this).data('price'));
                    });

                    const totalPayment = basePrice + addonCost;
                    $('#total_payment').text(totalPayment.toFixed(2));
                }

                // Event listeners for changes that affect total payment
                $('#wash_type, #weight, input[name="addons[]"]').on('change', calculateTotalPayment);

                // Limit add-on selections to 3
                $(document).on('change', 'input[name="addons[]"]', function() {
                    const maxAddons = 3;
                    if ($('input[name="addons[]"]:checked').length > maxAddons) {
                        this.checked = false;
                        alert('You can select a maximum of ' + maxAddons + ' add-ons.');
                    }
                    calculateTotalPayment();
                });
            });
        </script>
    </div>
</body>
</html>