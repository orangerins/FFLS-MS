<?php
session_start();
include('db_connection.php');

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Do not escape yet for password_hash

    // Check if username already exists
    $check_username_sql = "SELECT username FROM admin WHERE username = '$username'";
    $check_username_result = mysqli_query($conn, $check_username_sql);

    if (mysqli_num_rows($check_username_result) > 0) {
        $error = 'Username already exists. Please choose a different username.';
    } else {
        // Hash the password securely
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $insert_admin = "INSERT INTO admin (username, password) VALUES ('$username', '$hashed_password')";

        if (mysqli_query($conn, $insert_admin)) {
            $success = true;
            $message = 'Admin account created successfully! You will now be redirected to the login page.';
            // Redirect to admin login page after successful signup
            header("refresh:3;url=admin_login.php"); // Redirect after 3 seconds
            exit();
        } else {
            $error = 'Error creating admin account: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign Up</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            overflow: auto;
            flex-wrap: wrap;
        }

        .left-side {
            flex: 1;
            background: url('FFLSbg.jpg') no-repeat center center/cover;
        }

        .right-side {
            flex: 1;
            max-width: 500px;
            background-color: #d1e3ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            overflow-y: auto;
        }

        .logo {
            width: 230px;
            margin: 20px 0;
            align-self: center; /* Center the logo on the right side */
        }

        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 350px;
            text-align: left;
        }

        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .buttons {
            display: flex;
            justify-content: flex-start; /* Align buttons to the left */
            gap: 10px; /* Add some space between buttons */
            margin-top: 10px; /* Add some space above the buttons */
        }

        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }

        .signup {
            background-color: #6a9ff8;
            color: white;
        }

        .back-login {
            background-color: white;
            border: 1px solid #6a9ff8;
            color: #6a9ff8;
        }

        .back-login:hover {
            background-color: #6a9ff8;
            color: white;
        }

        .link-back-login {
            text-align: right; /* Align the "Back to Admin Login" link to the right */
            margin-top: 10px;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .left-side {
                display: none;
            }

            .right-side {
                width: 100%;
                max-width: none;
            }

            .logo {
                align-self: center; /* Center logo on smaller screens */
            }

            .link-back-login {
                text-align: center; /* Center link on smaller screens */
            }

            .buttons {
                justify-content: center; /* Center buttons on smaller screens */
            }
        }
    </style>
</head>
<body>
<div class="left-side"></div>
<div class="right-side">
    <img src="FFLSlogo.png" class="logo" alt="Logo">
    <div class="input-container">
        <h2>Admin Sign Up</h2>
        <?php if ($error): ?>
            <p style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if ($success): ?>
            <p style="color:green; margin-bottom:10px;"><?php echo htmlspecialchars($message); ?></p>
            <p class="link-back-login"><a href="admin_login.php">Back to Admin Login</a></p>
        <?php else: ?>
            <form method="POST" action="">
                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <div class="buttons">
                    <button class="signup" type="submit">Sign Up</button>
                </div>
            </form>
            <p class="link-back-login"><a href="admin_login.php">Back to Admin Login</a></p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>